﻿using System;

namespace _6___Deck{
    class Card{
        private string[] types = new string[]{"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};

        public int val;
        public string stringVal;
        public string suit;
        
        public Card(int val, string suit){
            this.val = val;
            this.stringVal = types[this.val-1];
            this.suit = suit;
        }
        public void show(){
            System.Console.WriteLine(this.stringVal + " of " + this.suit);
        }
    }


    class Deck{
        Random rand = new Random();

        public Card[] deck;

        public Deck(){
            this.deck = this.makeDeck();
        }

        
        
        public Card[] makeDeck(){
            Card[] localDeck = new Card[]{};
            string[] suits = new string[]{"Hearts", "Clubs", "Diamonds", "Spades"};
            for(var s = 0; s<suits.Length; s++){
                for(var i = 1; i<=13; i++){
                    localDeck = Program.appendToArray<Card>(localDeck, new Card(i, suits[s]));
                }
            }

            return localDeck;
        }
        
        public void shuffle(){
            for(var i = this.deck.Length - 1; i > 0; i--){
                var j = rand.Next(0, i+1);
                var temp = this.deck[i];
                this.deck[i] = this.deck[j];
                this.deck[j] = temp;
            }
        }
        
        public void reset(){
            this.deck = this.makeDeck();
        }
        public Card deal(){
            var temp = this.deck[this.deck.Length];

            Card[] newDeck = new Card[this.deck.Length-1];

            for(var i = 0; i < this.deck.Length - 1; i++){
                newDeck[i] = this.deck[i];
            }

            this.deck = new Card[newDeck.Length];

            for(var i = 0; i < newDeck.Length; i++){
                this.deck[i] = newDeck[i];
            }

            return temp;
        }
    }

    class Player{
        public string name;
        public Card[] hand;

        public Player(string name){
            this.name = name;
            this.hand = new Card[]{};
        }
        
        public void takeCard(Card card){
            var isValid = card as Card;
            if(isValid != null){
                this.hand = Program.appendToArray<Card>(this.hand, card);
            }
        }
        
        public Card discardCard(int idx){
            if(this.hand.Length == 0 || idx > this.hand.Length){ return null; }
            var temp = this.hand[idx];
            this.hand[idx] = this.hand[this.hand.Length-1];
            this.hand[this.hand.Length-1] = temp;

            Card[] newHand = new Card[this.hand.Length-1];

            for(var i = 0; i < this.hand.Length - 1; i++){
                newHand[i] = this.hand[i];
            }

            this.hand = new Card[newHand.Length];

            for(var i = 0; i < newHand.Length; i++){
                this.hand[i] = newHand[i];
            }

            return temp;
        }
    }


    class Program{
        public static T[] appendToArray<T>(T[] arr, T n){
            T[] newArray = new T[arr.Length+1];
            for(var i = 0; i<arr.LongLength; i++){
                newArray[i] = arr[i];
            }
            newArray[arr.Length] = n;
            return newArray;
        }

        static void Main(string[] args){
            Deck deck = new Deck();
            for(var i = 0; i<deck.deck.Length; i++){
                deck.deck[i].show();
            }
        }
    }
}
