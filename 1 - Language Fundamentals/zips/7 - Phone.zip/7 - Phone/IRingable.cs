interface IRingable{
    string Ring();
    string Unlock();
}
        