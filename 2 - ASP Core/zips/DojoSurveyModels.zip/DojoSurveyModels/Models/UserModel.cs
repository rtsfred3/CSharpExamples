using System;

namespace DojoSurveyModels.Models{
    public class UserModel{
        public string name{ get; set; }

        public string location{ get; set; }

        public string language{ get; set; }

        public string comments{ get; set; }
    }
}